# AI 모델 선택 기능

LangChain 기반 프로젝트에서 사용자가 UI를 통해 AI 모델(텍스트/비전)을 동적으로 선택할 수 있는 기능입니다.

## 📁 파일 구조

```
ai-model-selection-feature/
├── frontend/
│   ├── components/
│   │   └── ModelSelectionModal.tsx    # 모델 선택 모달 UI
│   ├── hooks/
│   │   └── useAISettings.ts          # AI 설정 관리 커스텀 훅
│   └── types/
│       └── ai-models.ts              # TypeScript 타입 정의
├── backend/
│   ├── ai_models_api.py              # FastAPI 엔드포인트
│   ├── ai_model.py                   # AI 모델 매니저 클래스
│   └── ai_models.json                # 모델 정보 데이터베이스
└── README.md
```

## 🚀 주요 기능

### Frontend
- **ModelSelectionModal**: 사용자가 모델을 선택할 수 있는 모달 컴포넌트
  - OpenAI, Google 등 여러 프로바이더 지원
  - 텍스트 모델과 비전 모델을 각각 선택 가능
  - API 키 입력 및 검증
  - localStorage에 설정 자동 저장
  - 모델별 가격 정보 표시

- **useAISettings**: AI 설정을 관리하는 React 커스텀 훅
  - 설정 로드/저장
  - 백엔드와 동기화
  - 설정 상태 관리

### Backend
- **GET /models**: 사용 가능한 모든 AI 모델 목록 조회 (ai_models.json에서 로드)
- **POST /set-ai-models**: 선택된 모델 설정 저장
- **GET /get-ai-models**: 현재 설정된 모델 정보 조회
- **AIModelManager**: JSON 파일에서 모델 정보를 로드하고 관리하는 클래스

## 📦 설치 및 사용

### Frontend 설치

```bash
# 필요한 패키지
npm install @headlessui/react @heroicons/react
```

### Frontend 사용 예시

```tsx
import { useState } from 'react';
import ModelSelectionModal from './components/ModelSelectionModal';
import { useAISettings } from './hooks/useAISettings';

function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { settings, saveSettings, isConfigured } = useAISettings();

  const handleSaveSettings = async (newSettings) => {
    const success = await saveSettings(newSettings);
    if (success) {
      console.log('설정 저장 완료');
    }
  };

  return (
    <div>
      {!isConfigured && (
        <div>설정이 필요합니다</div>
      )}

      <button onClick={() => setIsModalOpen(true)}>
        모델 설정
      </button>

      <ModelSelectionModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveSettings}
        currentSettings={settings}
      />
    </div>
  );
}
```

### Backend 설치 및 사용

```bash
# 필요한 패키지
pip install fastapi pydantic
```

```python
from fastapi import FastAPI
from backend.ai_models_api import router as ai_models_router

app = FastAPI()

# 라우터 등록
app.include_router(
    ai_models_router,
    prefix="/api/models",
    tags=["AI Models"]
)
```

**중요**: `ai_models.json` 파일은 `ai_model.py`와 같은 디렉토리에 위치해야 합니다. 다른 위치에 두려면 `AIModelManager` 초기화 시 경로를 지정하세요:

```python
model_manager = AIModelManager(config_path="/path/to/ai_models.json")
```

## 🔧 커스터마이징

### 모델 목록 추가/수정

`backend/ai_models.json` 파일을 수정하여 지원 모델을 추가하거나 변경할 수 있습니다:

```json
{
  "openai": {
    "gpt-4o-mini": {
      "name": "GPT-4o Mini",
      "input_modalities": ["text", "image"],
      "output_modalities": ["text"],
      "pricing": {
        "input": 0.15,
        "output": 0.60
      }
    }
  },
  "new-provider": {
    "model-id": {
      "name": "New Model",
      "input_modalities": ["text"],
      "output_modalities": ["text"],
      "pricing": {
        "input": 1.0,
        "output": 2.0
      }
    }
  }
}
```

### Pricing 옵션

- `input`: 입력 토큰 가격 (per 1M tokens)
- `output`: 출력 토큰 가격 (per 1M tokens)
- `input_audio`: 오디오 입력 가격 (선택사항)
- `input_over_128k`: 128k 이상 입력 가격 (선택사항)
- `output_over_128k`: 128k 이상 출력 가격 (선택사항)
- `input_over_200k`: 200k 이상 입력 가격 (선택사항)
- `output_over_200k`: 200k 이상 출력 가격 (선택사항)

### API 엔드포인트 변경

기본적으로 `/api/models` prefix를 사용합니다. 변경하려면:

1. Backend: FastAPI 라우터 등록 시 prefix 수정
2. Frontend: `useAISettings.ts`와 `ModelSelectionModal.tsx`에서 API URL 수정

## 💡 특징

- ✅ JSON 기반 모델 데이터베이스
- ✅ localStorage를 통한 브라우저 영구 저장
- ✅ 백엔드와 자동 동기화
- ✅ API 키 입력 및 테스트 지원
- ✅ 모델별 가격 정보 표시
- ✅ 모달리티 필터링 (텍스트/이미지/오디오/비디오)
- ✅ 반응형 UI
- ✅ TypeScript 완전 지원

## 📝 라이센스

MIT License

## 🤝 기여

이슈나 PR은 언제든 환영합니다!
