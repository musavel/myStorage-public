"""
AI 모델 선택 기능 - Backend API
FastAPI 라우터에 추가할 엔드포인트들
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
import logging
from .ai_model import AIModelManager

logger = logging.getLogger(__name__)

router = APIRouter()

# AI 모델 매니저 초기화
try:
    model_manager = AIModelManager()  # ai_models.json을 자동으로 로드
    logger.info("✅ AI 모델 매니저 초기화 성공")
except Exception as e:
    logger.error(f"❌ AI 모델 매니저 초기화 실패: {e}")
    model_manager = None

# 전역 변수로 현재 설정 저장
current_ai_settings = {
    "text_model": None,
    "vision_model": None
}

# Pydantic 모델 정의
class ModelSelection(BaseModel):
    provider: str
    modelId: str

class AISettingsRequest(BaseModel):
    textModel: Optional[ModelSelection] = None
    visionModel: Optional[ModelSelection] = None

@router.get("/models")
async def get_available_models():
    """
    사용 가능한 AI 모델 목록을 반환합니다.
    ai_models.json 파일에서 로드된 모델 정보를 제공합니다.
    """
    logger.info("📋 모델 목록 요청")

    if model_manager is None:
        raise HTTPException(
            status_code=500,
            detail="모델 매니저가 초기화되지 않았습니다."
        )

    try:
        # AI 모델 매니저에서 모든 모델 가져오기
        all_models = model_manager.get_all_models()

        # Pydantic 모델에 맞게 변환
        formatted_models = {}
        for provider, models in all_models.items():
            formatted_models[provider] = {}
            for model_id, config in models.items():
                formatted_models[provider][model_id] = {
                    "name": config.name,
                    "input_modalities": config.input_modalities,
                    "output_modalities": config.output_modalities,
                    "pricing": {
                        "input": config.pricing.input,
                        "output": config.pricing.output,
                        **({"input_audio": config.pricing.input_audio} if config.pricing.input_audio else {}),
                        **({"input_over_128k": config.pricing.input_over_128k} if config.pricing.input_over_128k else {}),
                        **({"output_over_128k": config.pricing.output_over_128k} if config.pricing.output_over_128k else {}),
                        **({"input_over_200k": config.pricing.input_over_200k} if config.pricing.input_over_200k else {}),
                        **({"output_over_200k": config.pricing.output_over_200k} if config.pricing.output_over_200k else {}),
                    }
                }

        return {
            "success": True,
            "models": formatted_models
        }

    except Exception as e:
        logger.error(f"❌ 모델 목록 조회 실패: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"모델 목록 조회 중 오류가 발생했습니다: {str(e)}"
        )

@router.post("/set-ai-models")
async def set_ai_models(settings: AISettingsRequest):
    """
    프론트엔드에서 선택한 AI 모델 설정을 저장합니다.
    """
    global current_ai_settings

    try:
        # 설정 저장
        if settings.textModel:
            current_ai_settings["text_model"] = {
                "provider": settings.textModel.provider,
                "model_id": settings.textModel.modelId
            }
            logger.info(f"📝 텍스트 모델 설정: {settings.textModel.provider}/{settings.textModel.modelId}")

        if settings.visionModel:
            current_ai_settings["vision_model"] = {
                "provider": settings.visionModel.provider,
                "model_id": settings.visionModel.modelId
            }
            logger.info(f"👁️ 비전 모델 설정: {settings.visionModel.provider}/{settings.visionModel.modelId}")

        logger.info(f"✅ AI 모델 설정 완료: {current_ai_settings}")

        return {
            "success": True,
            "message": "AI 모델 설정이 저장되었습니다.",
            "settings": current_ai_settings
        }

    except Exception as e:
        logger.error(f"❌ AI 모델 설정 실패: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"AI 모델 설정 중 오류가 발생했습니다: {str(e)}"
        )

@router.get("/get-ai-models")
async def get_ai_models():
    """
    현재 설정된 AI 모델 정보를 반환합니다.
    """
    return {
        "success": True,
        "settings": current_ai_settings
    }

# 사용 예시:
# app = FastAPI()
# app.include_router(router, prefix="/api/models", tags=["AI Models"])
