import { useState, useEffect } from 'react';
import type { AISettings } from '../types/ai-models';

const STORAGE_KEY = 'ai-settings';

const defaultSettings: AISettings = {
  textModel: null,
  visionModel: null
};

export function useAISettings() {
  const [settings, setSettings] = useState<AISettings>(defaultSettings);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    // 로컬 스토리지에서 설정 로드
    const loadAndSyncSettings = async () => {
      try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
          const parsedSettings = JSON.parse(saved);
          setSettings({ ...defaultSettings, ...parsedSettings });
          
          // 백엔드와 동기화 (모델이 설정되어 있는 경우에만)
          if (parsedSettings.textModel || parsedSettings.visionModel) {
            try {
              await fetch('http://localhost:8011/api/grading/set-ai-models', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify(parsedSettings),
              });
              console.log('🔄 기존 설정을 백엔드와 동기화했습니다.');
            } catch (syncError) {
              console.error('❌ 백엔드 동기화 실패:', syncError);
            }
          }
        }
      } catch (error) {
        console.error('Failed to load AI settings:', error);
      } finally {
        setIsLoaded(true);
      }
    };

    loadAndSyncSettings();
  }, []);

  const saveSettings = async (newSettings: AISettings): Promise<boolean> => {
    try {
      // 로컬스토리지에 저장
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newSettings));
      setSettings(newSettings);
      
      // 백엔드에도 설정 전달
      try {
        const response = await fetch('http://localhost:8011/api/grading/set-ai-models', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(newSettings),
        });
        
        const result = await response.json();
        if (result.success) {
          console.log('✅ 백엔드에 AI 모델 설정이 저장되었습니다.');
        } else {
          console.error('❌ 백엔드 설정 저장 실패:', result);
        }
      } catch (backendError) {
        console.error('❌ 백엔드로 설정 전달 실패:', backendError);
        // 백엔드 실패해도 로컬 저장은 성공으로 처리
      }
      
      return true;
    } catch (error) {
      console.error('Failed to save settings:', error);
      return false;
    }
  };

  const isConfigured = () => {
    return settings.textModel !== null || settings.visionModel !== null;
  };

  return {
    settings,
    saveSettings,
    isConfigured: isConfigured(),
    isLoaded
  };
}