import { useState, useEffect, Fragment } from 'react';
import { Dialog, Transition, RadioGroup } from '@headlessui/react';
import { XMarkIcon, CogIcon, CheckCircleIcon, ArrowPathIcon, WifiIcon, TrashIcon } from '@heroicons/react/24/outline';
import type { AIModelsData, AISettings, ModelSelection } from '../types/ai-models';
import { useAPIStatus } from '../hooks/useAPIStatus';
import clsx from 'clsx';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSave: (settings: AISettings) => void;
  currentSettings: AISettings;
}

export default function ModelSelectionModal({ isOpen, onClose, onSave, currentSettings }: Props) {
  const [models, setModels] = useState<AIModelsData>({});
  const [textModel, setTextModel] = useState<ModelSelection | null>(currentSettings.textModel);
  const [visionModel, setVisionModel] = useState<ModelSelection | null>(currentSettings.visionModel);
  const [loading, setLoading] = useState(false);
  const [testLoading, setTestLoading] = useState(false);
  const [testResult, setTestResult] = useState<{ 
    success: boolean; 
    message: string; 
    details?: any;
    timestamp?: string;
  } | null>(null);
  const { status, loading: apiLoading, checkAPIStatus, getStatusColor, getStatusText } = useAPIStatus();

  // 설정이 변경될 때마다 로컬 상태 업데이트
  useEffect(() => {
    setTextModel(currentSettings.textModel);
    setVisionModel(currentSettings.visionModel);
  }, [currentSettings]);

  useEffect(() => {
    // FastAPI에서 모델 목록 가져오기
    const fetchModels = async () => {
      try {
        console.log('📡 FastAPI에서 모델 목록 가져오는 중...');
        
        const response = await fetch('http://localhost:8011/api/models');
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (result.success && result.models) {
          console.log('✅ FastAPI에서 모델 목록 가져오기 성공:', result.models);
          setModels(result.models);
        } else {
          throw new Error('모델 목록 응답 형식이 올바르지 않습니다.');
        }
        
      } catch (error) {
        console.error('❌ FastAPI에서 모델 목록 가져오기 실패:', error);
        
        // 폴백: 빈 객체로 설정
        setModels({});
        
        // 사용자에게 알림
        setTestResult({
          success: false,
          message: `FastAPI 연결 실패: ${error instanceof Error ? error.message : '알 수 없는 오류'}`
        });
      }
    };

    fetchModels();
  }, []);

  const handleSave = async () => {
    setLoading(true);
    try {
      const settings: AISettings = {
        textModel,
        visionModel
      };
      onSave(settings);
      onClose();
    } catch (error) {
      console.error('Failed to save settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleTestConnection = async () => {
    setTestLoading(true);
    setTestResult(null);
    
    try {
      const settings: AISettings = {
        textModel,
        visionModel
      };

      const response = await fetch('http://localhost:8011/api/test-connection', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ settings }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      
      setTestResult({
        success: result.success,
        message: result.message,
        details: result,
        timestamp: new Date(result.timestamp).toLocaleString()
      });

      console.log('🧪 연결 테스트 결과:', result);
      
    } catch (error) {
      console.error('연결 테스트 실패:', error);
      setTestResult({
        success: false,
        message: `연결 테스트 실패: ${error instanceof Error ? error.message : '알 수 없는 오류'}`
      });
    } finally {
      setTestLoading(false);
    }
  };

  const handleReset = () => {
    setTextModel(null);
    setVisionModel(null);
    setTestResult(null);
  };

  const getModalityBadgeColor = (modality: string) => {
    const colors = {
      text: 'bg-blue-100 text-blue-800',
      image: 'bg-green-100 text-green-800',
      audio: 'bg-purple-100 text-purple-800',
      video: 'bg-red-100 text-red-800',
      pdf: 'bg-orange-100 text-orange-800'
    };
    return colors[modality as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  // 텍스트 전용 모델 필터링
  const getTextModels = () => {
    const textModels: AIModelsData = {};
    Object.entries(models).forEach(([provider, providerModels]) => {
      textModels[provider] = {};
      Object.entries(providerModels).forEach(([modelId, config]) => {
        if (config.input_modalities.includes('text')) {
          textModels[provider][modelId] = config;
        }
      });
    });
    return textModels;
  };

  // 비전 모델 필터링 (이미지 입력 가능)
  const getVisionModels = () => {
    const visionModels: AIModelsData = {};
    Object.entries(models).forEach(([provider, providerModels]) => {
      visionModels[provider] = {};
      Object.entries(providerModels).forEach(([modelId, config]) => {
        if (config.input_modalities.includes('image')) {
          visionModels[provider][modelId] = config;
        }
      });
    });
    return visionModels;
  };

  // 모델 선택 비교 함수
  const isModelSelected = (model: ModelSelection | null, compareModel: ModelSelection) => {
    return model?.provider === compareModel.provider && model?.modelId === compareModel.modelId;
  };

  const ModelSelectionSection = ({ 
    title, 
    models, 
    selectedModel, 
    onModelChange 
  }: {
    title: string;
    models: AIModelsData;
    selectedModel: ModelSelection | null;
    onModelChange: (model: ModelSelection | null) => void;
  }) => (
    <div>
      <h4 className="text-sm font-medium text-gray-900 mb-3">{title}</h4>
      <div className="space-y-3">
        {Object.entries(models).map(([provider, providerModels]) => (
          <div key={provider} className="border rounded-lg p-4">
            <h5 className="text-sm font-semibold text-gray-800 mb-3 capitalize">
              {provider === 'openai' ? 'OpenAI' : 'Google'}
            </h5>
            <div className="grid grid-cols-1 gap-2">
              {Object.entries(providerModels).map(([modelId, config]) => {
                const currentModel = { provider, modelId };
                const isSelected = isModelSelected(selectedModel, currentModel);
                
                return (
                  <div
                    key={`${provider}-${modelId}`}
                    onClick={() => {
                      // 현재 선택된 모델을 다시 클릭하면 선택 해제
                      if (isSelected) {
                        onModelChange(null);
                      } else {
                        onModelChange(currentModel);
                      }
                    }}
                    className={clsx(
                      'relative flex cursor-pointer rounded-lg px-4 py-3 shadow-sm focus:outline-none transition-all duration-200',
                      isSelected ? 'bg-indigo-50 border-indigo-200 ring-2 ring-indigo-500 ring-offset-1' : 'bg-white border-gray-200 hover:bg-gray-50',
                      'border'
                    )}
                  >
                    <div className="flex w-full items-start justify-between">
                      <div className="flex-1">
                        <p className={clsx(
                          'font-medium text-sm',
                          isSelected ? 'text-indigo-900' : 'text-gray-900'
                        )}>
                          {config.name}
                        </p>
                        
                        <div className="flex flex-wrap gap-1 mt-2">
                          <span className="text-xs text-gray-500 mr-1">입력:</span>
                          {config.input_modalities.map((modality) => (
                            <span
                              key={modality}
                              className={clsx(
                                'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium',
                                getModalityBadgeColor(modality)
                              )}
                            >
                              {modality}
                            </span>
                          ))}
                        </div>
                        
                        <div className="grid grid-cols-2 gap-2 mt-2 text-xs">
                          <div className="text-gray-600">
                            <span className="font-medium">입력:</span> ${config.pricing.input}/1M 토큰
                          </div>
                          <div className="text-gray-600">
                            <span className="font-medium">출력:</span> ${config.pricing.output}/1M 토큰
                          </div>
                        </div>
                      </div>
                      
                      {isSelected && (
                        <div className="shrink-0 text-indigo-600 ml-3 animate-in fade-in duration-200">
                          <CheckCircleIcon className="h-5 w-5" />
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <Transition appear show={isOpen} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={onClose}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black/25" />
        </Transition.Child>

        <div className="fixed inset-0 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4 text-center">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 scale-95"
              enterTo="opacity-100 scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 scale-100"
              leaveTo="opacity-0 scale-95"
            >
              <Dialog.Panel className="w-full max-w-6xl transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <CogIcon className="h-6 w-6 text-gray-500" />
                    <Dialog.Title as="h3" className="text-lg font-medium leading-6 text-gray-900">
                      AI 모델 설정
                    </Dialog.Title>
                  </div>
                  <button
                    onClick={onClose}
                    className="rounded-md p-2 hover:bg-gray-100 transition-colors"
                  >
                    <XMarkIcon className="h-5 w-5 text-gray-500" />
                  </button>
                </div>

                {/* API 키 상태 표시 */}
                <div className="mb-6 p-4 bg-gray-50 border border-gray-200 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-sm font-medium text-gray-900">API 키 연결 상태</h4>
                    <button
                      onClick={checkAPIStatus}
                      disabled={apiLoading}
                      className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-gray-600 bg-white border border-gray-300 rounded hover:bg-gray-50 disabled:opacity-50"
                    >
                      <ArrowPathIcon className={clsx("w-3 h-3", apiLoading && "animate-spin")} />
                      새로고침
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center justify-between p-3 bg-white border rounded-lg">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-gray-700">OpenAI</span>
                      </div>
                      <div className={clsx(
                        "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium",
                        getStatusColor('openai')
                      )}>
                        <div className={clsx(
                          "w-1.5 h-1.5 rounded-full mr-1",
                          status.openai === 'connected' && "bg-green-500",
                          status.openai === 'error' && "bg-red-500",
                          status.openai === 'unknown' && "bg-gray-500"
                        )} />
                        {getStatusText('openai')}
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-white border rounded-lg">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-gray-700">Google</span>
                      </div>
                      <div className={clsx(
                        "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium",
                        getStatusColor('google')
                      )}>
                        <div className={clsx(
                          "w-1.5 h-1.5 rounded-full mr-1",
                          status.google === 'connected' && "bg-green-500",
                          status.google === 'error' && "bg-red-500",
                          status.google === 'unknown' && "bg-gray-500"
                        )} />
                        {getStatusText('google')}
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-xs text-gray-500 mt-3">
                    💡 연결 오류 시 서버 설정을 확인하세요.
                  </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <ModelSelectionSection
                    title="📝 텍스트 모델"
                    models={getTextModels()}
                    selectedModel={textModel}
                    onModelChange={setTextModel}
                  />
                  
                  <ModelSelectionSection
                    title="👁️ 비전 모델 (이미지 분석)"
                    models={getVisionModels()}
                    selectedModel={visionModel}
                    onModelChange={setVisionModel}
                  />
                </div>

                {/* 테스트 결과 표시 */}
                {testResult && (
                  <div className={clsx(
                    "mt-6 p-4 rounded-lg border",
                    testResult.success ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
                  )}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className={clsx(
                          "w-2 h-2 rounded-full",
                          testResult.success ? "bg-green-500" : "bg-red-500"
                        )} />
                        <p className={clsx(
                          "text-sm font-medium",
                          testResult.success ? "text-green-800" : "text-red-800"
                        )}>
                          {testResult.success ? "✅ 연결 테스트 성공" : "❌ 연결 테스트 실패"}
                        </p>
                      </div>
                      {testResult.timestamp && (
                        <span className="text-xs text-gray-500">
                          {testResult.timestamp}
                        </span>
                      )}
                    </div>
                    
                    <p className={clsx(
                      "text-sm mt-2",
                      testResult.success ? "text-green-700" : "text-red-700"
                    )}>
                      {testResult.message}
                    </p>

                    {/* API 응답 상세 정보 */}
                    {testResult.success && testResult.details?.test_results && (
                      <div className="mt-3 space-y-2">
                        <h5 className="text-xs font-medium text-green-800">📊 테스트 상세 결과:</h5>
                        <div className="bg-white rounded border p-3 space-y-2">
                          {testResult.details.test_results.text_model && (
                            <div className="flex items-center gap-2 text-xs">
                              <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                              <span className="font-medium">텍스트 모델:</span>
                              <span className="text-gray-600">
                                {testResult.details.test_results.text_model.provider}/{testResult.details.test_results.text_model.model_id}
                              </span>
                              <span className="text-green-600 font-medium">
                                {testResult.details.test_results.text_model.status}
                              </span>
                            </div>
                          )}
                          {testResult.details.test_results.vision_model && (
                            <div className="flex items-center gap-2 text-xs">
                              <span className="w-2 h-2 bg-purple-500 rounded-full"></span>
                              <span className="font-medium">비전 모델:</span>
                              <span className="text-gray-600">
                                {testResult.details.test_results.vision_model.provider}/{testResult.details.test_results.vision_model.model_id}
                              </span>
                              <span className="text-green-600 font-medium">
                                {testResult.details.test_results.vision_model.status}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* 원시 API 응답 (개발용) */}
                    {testResult.details && (
                      <details className="mt-3">
                        <summary className="text-xs text-gray-500 cursor-pointer hover:text-gray-700">
                          🔍 원시 API 응답 보기 (개발용)
                        </summary>
                        <pre className="mt-2 text-xs bg-gray-100 p-2 rounded overflow-x-auto max-h-32">
                          {JSON.stringify(testResult.details, null, 2)}
                        </pre>
                      </details>
                    )}
                  </div>
                )}

                <div className="mt-8 flex justify-between">
                  <div className="flex gap-3">
                    <button
                      type="button"
                      className="inline-flex items-center gap-2 rounded-md border border-blue-300 bg-blue-50 px-4 py-2 text-sm font-medium text-blue-700 shadow-sm hover:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
                      onClick={handleTestConnection}
                      disabled={testLoading || (!textModel && !visionModel)}
                    >
                      <WifiIcon className={clsx("w-4 h-4", testLoading && "animate-pulse")} />
                      {testLoading ? '전송 중...' : '설정 전송 테스트'}
                    </button>
                    
                    <button
                      type="button"
                      className="inline-flex items-center gap-2 rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
                      onClick={handleReset}
                      disabled={!textModel && !visionModel}
                    >
                      <TrashIcon className="w-4 h-4" />
                      모두 초기화
                    </button>
                  </div>
                  
                  <div className="flex gap-3">
                    <button
                      type="button"
                      className="inline-flex justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                      onClick={onClose}
                    >
                      취소
                    </button>
                    <button
                      type="button"
                      className="inline-flex justify-center rounded-md border border-transparent bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
                      onClick={handleSave}
                      disabled={loading}
                    >
                      {loading ? '저장 중...' : '설정 저장'}
                    </button>
                  </div>
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
}