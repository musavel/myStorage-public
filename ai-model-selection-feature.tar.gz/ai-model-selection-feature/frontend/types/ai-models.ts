export interface PricingInfo {
  input: number;
  output: number;
  input_audio?: number;
  input_over_128k?: number;
  output_over_128k?: number;
  input_over_200k?: number;
  output_over_200k?: number;
}

export interface AIModelConfig {
  name: string;
  input_modalities: string[];
  output_modalities: string[];
  pricing: PricingInfo;
}

export interface AIModelsData {
  [provider: string]: {
    [modelId: string]: AIModelConfig;
  };
}

export interface ModelSelection {
  provider: string;
  modelId: string;
}

export interface AISettings {
  textModel: ModelSelection | null;
  visionModel: ModelSelection | null;
}

